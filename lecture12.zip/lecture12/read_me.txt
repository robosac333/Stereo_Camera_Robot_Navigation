1) source /install/lecture12/share/lecture12/local_setup.zsh (Source the package using this command)
2) We were having some building issues so we ended up not changing the package name. 
   So the name of the package is still lecture12

